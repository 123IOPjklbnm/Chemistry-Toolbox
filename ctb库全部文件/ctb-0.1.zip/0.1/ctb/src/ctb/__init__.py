"""ctb —— 化学工具箱核心库。

用法:
    >>> from ctb import balance
    >>> balance("H2+O2=H2O")
    '2H2+O2=2H2O'
"""

from ._balance import balance
from ._formula import parse_formula

__version__ = "0.1.0"
__all__ = ["balance", "parse_formula"]