# ctb

化学工具箱核心库：化学方程式配平。

## 安装

```bash
pip install ctb
```

## 用法

```python
from ctb import balance

# 普通方程式
balance("H2+O2=H2O")                 # '2H2+O2=2H2O'
balance("Fe2O3+CO=Fe+CO2")           # 'Fe2O3+3CO=2Fe+3CO2'

# 支持箭头
balance("H2+O2->H2O")                # '2H2+O2=2H2O'

# 离子方程式：^数字+ 表示正电荷，^数字- 表示负电荷
balance("H^1++OH^1-=H2O")            # 'H^1++OH^1-=H2O'
balance("CO3^2-+H^1+=HCO3^1-")       # 'CO3^2-+H^1+=HCO3^1-'
```

## 输入格式约定

| 符号 | 含义 |
|------|------|
| `=` 或 `->` 或 `→` | 反应箭头 |
| `+` | 分隔化合物 |
| `^n+` | 带 n 个正电荷（如 `H^1+`、`Fe^3+`） |
| `^n-` | 带 n 个负电荷（如 `CO3^2-`、`SO4^2-`） |
| 括号 | 支持 `()` 与 `[]`，可嵌套 |

## 返回

返回配平后的方程式字符串（不含空格）。

## 错误

格式错误或无法配平时抛出 `ValueError`。

## 许可证

MIT License
Copyright (c) 2026 123IOPjklbnm
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 